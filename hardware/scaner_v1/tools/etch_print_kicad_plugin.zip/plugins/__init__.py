# Пакет «Печать для травления» для менеджера плагинов KiCad (собран etch_window.py --pack)
from .etch_window import EtchPrintPlugin
EtchPrintPlugin().register()
